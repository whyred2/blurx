import React, { useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const GoogleCallback = () => {
    const navigate = useNavigate(); 

  useEffect(() => {
    const handleGoogleCallback = async () => {
        console.log('Authorization code:', code); 
      const urlParams = new URLSearchParams(window.location.search);
      const code = urlParams.get('code');
      console.log('Authorization code:', code); 
      if (code) {
        console.log('Authorization code:', code); // Добавим логирование

        try {
          const response = await axios.post(`${process.env.REACT_APP_SERVER_URL}/auth/google`, { code });
          console.log('Server response:', response.data); // Добавим логирование
          
          const { user, token } = response.data;

          localStorage.setItem('user', JSON.stringify(user));
          localStorage.setItem('token', token);
          return navigate('/profile');
        } catch (error) {
          console.error('Login failed:', error); // Добавим логирование
          alert('Ошибка авторизации. Пожалуйста, попробуйте снова.');
          return navigate('/');
        }
      } else {
        console.error('No authorization code found'); // Добавим логирование
        alert('Код авторизации не найден.');
        return navigate('/');
      }
    };

    return handleGoogleCallback();
  }, []);

  return <div>Загрузка...</div>;
};

export default GoogleCallback;
