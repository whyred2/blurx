import React from 'react';

const Search = () => {
    return (
        <>asdasd</>
    );
}
 
export default Search;